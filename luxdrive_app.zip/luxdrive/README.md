# LuxDrive — Premium Car Browsing App

A production-grade Flutter app for browsing luxury vehicles, built with **Riverpod**, clean architecture, premium dark UI, and full animation support.

---

## 📁 Project Structure

```
luxdrive/
├── lib/
│   ├── main.dart                          # App entry point
│   ├── core/
│   │   ├── theme/
│   │   │   └── app_theme.dart             # Dark + Light ThemeData, colors, text styles
│   │   └── utils/
│   │       └── formatters.dart            # Price/currency formatters
│   ├── data/
│   │   ├── models/
│   │   │   └── car_model.dart             # CarModel + CarSpecs data classes
│   │   ├── providers/
│   │   │   └── car_provider.dart          # All Riverpod providers (cars, filter, favorites, theme)
│   │   └── repositories/
│   │       └── car_repository.dart        # 60+ real car entries (maps to your 150 images)
│   └── presentation/
│       ├── screens/
│       │   ├── main_shell.dart            # Bottom nav shell
│       │   ├── home/
│       │   │   ├── home_screen.dart       # Grid + List home with CustomScrollView
│       │   │   └── widgets/
│       │   │       ├── home_header.dart   # Logo, theme toggle, notifications
│       │   │       ├── search_bar_widget.dart
│       │   │       ├── featured_section.dart  # Horizontal featured cards
│       │   │       ├── brand_filter_row.dart  # Horizontal brand chips
│       │   │       └── filter_bar.dart    # Sort/Filter + view toggle
│       │   ├── detail/
│       │   │   └── car_detail_screen.dart # Hero, carousel, specs, CTA
│       │   ├── favorites/
│       │   │   └── favorites_screen.dart
│       │   └── profile/
│       │       └── profile_screen.dart
│       └── widgets/
│           └── car_card/
│               └── car_grid_card.dart     # Grid card, List card, Featured card
├── assets/
│   ├── images/
│   │   └── cars/                          # ← DROP YOUR 150 IMAGES HERE
│   └── fonts/                             # ← DROP URBANIST FONTS HERE
└── pubspec.yaml
```

---

## 🖼️ Where to Place Your 150 Images

Place all car images in:
```
assets/images/cars/
```

Name them **exactly** as:
```
car_1.jpg
car_2.jpg
car_3.jpg
...
car_150.jpg
```

The app maps `car_repository.dart` entries to images by index automatically. If you have images in a different format (`.png`, `.webp`), change the extension in `car_repository.dart`:

```dart
imagePath: 'assets/images/cars/car_$imageIndex.jpg',  // change .jpg here
```

---

## 🔤 Fonts Setup

This app uses **Urbanist** — a premium sans-serif font available free from Google Fonts.

**Download:** https://fonts.google.com/specimen/Urbanist

Place these files in `assets/fonts/`:
```
Urbanist-Regular.ttf
Urbanist-Medium.ttf
Urbanist-SemiBold.ttf
Urbanist-Bold.ttf
Urbanist-ExtraBold.ttf
```

> **Quick alternative:** If you want to skip local fonts, replace `'Urbanist'` with `'Roboto'` everywhere in `app_theme.dart` — it works as a fallback.

---

## 📦 Setup Steps

```bash
# 1. Navigate to project
cd luxdrive

# 2. Install dependencies
flutter pub get

# 3. Add your 150 images to assets/images/cars/

# 4. Add Urbanist font files to assets/fonts/

# 5. Run the app
flutter run
```

---

## 📲 Features Implemented

| Feature | Status |
|---|---|
| Premium dark theme | ✅ |
| Light theme toggle | ✅ |
| Home grid view | ✅ |
| Home list view | ✅ |
| Featured horizontal carousel | ✅ |
| Brand filter row | ✅ |
| Search (live) | ✅ |
| Filter by brand / category / fuel / price | ✅ |
| Sort (6 options) | ✅ |
| Hero animation (list → detail) | ✅ |
| Image carousel with page indicator | ✅ |
| Car specs grid | ✅ |
| Color selector | ✅ |
| Favorites with persistence | ✅ |
| Test Drive booking sheet | ✅ |
| Buy Now purchase sheet | ✅ |
| Profile + Settings screen | ✅ |
| Staggered list animations | ✅ |
| Press scale micro-interactions | ✅ |
| Responsive design | ✅ |

---

## 🧠 Why Riverpod?

We chose **Riverpod** over Bloc or Provider because:

1. **Compile-safe** — no `context.read<T>()` strings that break silently
2. **Zero context dependency** — providers work anywhere, including repositories and services
3. **Fine-grained reactivity** — `ref.watch(filteredCarsProvider)` only rebuilds when the filtered list changes, not on every state mutation
4. **Simpler than Bloc** for this use case — Bloc is ideal for complex event streams; Riverpod's `StateNotifier` handles filter/favorites cleanly without boilerplate
5. **Built-in `AsyncValue`** — ready for future backend integration with `FutureProvider`

---

## 🔧 Performance Optimization Tips

### Current (150 local images)
- Images are loaded lazily via `ListView`/`SliverGrid` — only visible items are rendered
- `IndexedStack` in `MainShell` preserves scroll position between tabs
- `SliverPersistentHeader` pins the filter bar without rebuilding the list
- `const` constructors used everywhere possible

### At Scale (500–10,000 cars)
```dart
// 1. Use CachedNetworkImage for remote images
CachedNetworkImage(
  imageUrl: car.imageUrl,
  placeholder: (_, __) => ShimmerPlaceholder(),
  memCacheWidth: 400, // Decode at display size only
)

// 2. Replace Provider-based list with pagination
final carsPageProvider = FutureProvider.family<List<CarModel>, int>((ref, page) async {
  return await ref.read(apiServiceProvider).getCars(page: page, limit: 20);
});

// 3. Use flutter_cache_manager for disk caching
// 4. Add RepaintBoundary around each card

// 5. Pre-cache detail images on hover
precacheImage(AssetImage(car.galleryImages[1]), context);
```

---

## 🚀 Scaling to Backend (Firebase or REST API)

### Step 1 — Abstract the repository

```dart
// Create an abstract interface
abstract class ICarRepository {
  Future<List<CarModel>> getAllCars();
  Future<List<CarModel>> searchCars(String query);
}

// Local implementation (current)
class LocalCarRepository implements ICarRepository { ... }

// Firebase implementation
class FirebaseCarRepository implements ICarRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  
  @override
  Future<List<CarModel>> getAllCars() async {
    final snap = await _db.collection('cars').get();
    return snap.docs.map((d) => CarModel.fromJson(d.data())).toList();
  }
}

// REST API implementation
class ApiCarRepository implements ICarRepository {
  final Dio _dio;
  
  @override
  Future<List<CarModel>> getAllCars() async {
    final res = await _dio.get('/api/cars');
    return (res.data as List).map((j) => CarModel.fromJson(j)).toList();
  }
}
```

### Step 2 — Add `fromJson`/`toJson` to `CarModel`

```dart
factory CarModel.fromJson(Map<String, dynamic> json) => CarModel(
  id: json['id'],
  name: json['name'],
  brand: json['brand'],
  price: (json['price'] as num).toDouble(),
  imagePath: json['imageUrl'], // remote URL from storage
  // ...
);
```

### Step 3 — Switch provider to FutureProvider

```dart
final allCarsProvider = FutureProvider<List<CarModel>>((ref) async {
  return ref.watch(carRepositoryProvider).getAllCars();
});
```

### Step 4 — Add Firebase Auth, Favorites to Firestore

```dart
// Sync favorites to user document
Future<void> toggle(String carId) async {
  // Local update (instant UI)
  state = updatedSet;
  
  // Remote sync (non-blocking)
  final uid = FirebaseAuth.instance.currentUser?.uid;
  if (uid != null) {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'favorites': FieldValue.arrayUnion([carId])});
  }
}
```

---

## 🎨 Design System

| Token | Value |
|---|---|
| Primary background (dark) | `#0A0A0F` |
| Surface (dark) | `#12121A` |
| Card (dark) | `#1A1A26` |
| Gold accent | `#D4AF37` |
| Font | Urbanist (800, 700, 600, 500, 400) |
| Border radius (card) | 24px |
| Border radius (button) | 16px |

---

## 📱 Screenshots Description

- **Home (Grid):** 2-column masonry-style grid with gold-accented brand labels, fuel type badges, heart favorites
- **Home (List):** Full-width cards with inline spec chips (0–100, HP)
- **Featured:** Cinematic horizontal cards with full-image backgrounds and gradient overlays
- **Detail:** Hero-animated image → large carousel → quick spec pills → color selector → full specs table → sticky buy/test-drive CTA
- **Favorites:** Same grid view filtered to saved cars
- **Profile:** Gold membership badge, stats, settings with dark mode toggle
